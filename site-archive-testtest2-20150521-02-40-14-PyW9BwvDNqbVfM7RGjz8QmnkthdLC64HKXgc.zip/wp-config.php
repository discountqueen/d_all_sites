<?php
# Database Configuration
define( 'DB_NAME', 'wp_testtest2' );
define( 'DB_USER', 'testtest2' );
define( 'DB_PASSWORD', '749fYt2JyMQHVBW6' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY', ',{aC.+(x7n3H3hjV]rH~_*~s5JcI!Q+y.ec;9_[LXz+/.;g6)ApGjEmYwF676{Sm');
define('SECURE_AUTH_KEY', 'zb5mfdHi5NS0i>K?S$zu(Ab,/Qi7l=^PA&aTmmXRV(yQ#={-x+{I3r7Z(&6$*St(');
define('LOGGED_IN_KEY', 'q|>]{-iK9VkF:1*T#z1MJEUIwbd#T2-M!Ux39Z%^Sg1H_5W@BEcq}1EIrGzI?:|q');
define('NONCE_KEY', 'X0X}Vve.p =z2{~d+>H{$#fp]WW HY2/LiGse:0r9 /=MT8INtmx(3k?L ROByWR');
define('AUTH_SALT',        '=(%IKt8C/NqotoT5k`aJx=FjZ:Lf)5s7eQ$ZW{h,f3Mt`DD00[A(M[%l2PTwH+V&');
define('SECURE_AUTH_SALT', 'JJ|<_WhZ*a0;)0`8DM6ha6#-pxNcn+T]WVe)sa5Yz5q1sDdzzrlk@dKCg7a.lcQJ');
define('LOGGED_IN_SALT',   '~]h KQb*+YxO/|Vi!M%Fv@b5=(*5c:[f1mY_+06l@,.E9[w@@0Z6cNC:78+F:|0&');
define('NONCE_SALT',       '11QY`i@_.J`!7HH7N/O^%W7-x=$:ye+CDJKc#iLGfz-~?Z(b$BiSY=^7U08/B_KZ');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'PWP_NAME', 'testtest2' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', '799cd630a2aac9d230c077951efc05386673d442' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '40103' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_CDN_DISABLE_ALLOWED', false );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'testtest2.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-40103', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );

define( 'WPE_BETA_TESTER', false );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_AUTO_UPDATE_CORE', false );

$wpe_special_ips=array ( 0 => '45.56.116.175', );

$wpe_netdna_domains_secure=array ( );

define( 'WPE_CACHE_TYPE', 'generational' );

define( 'WPE_LBMASTER_IP', '45.56.116.175' );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_HYPER_DB', 'safe' );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
