<?php
# Database Configuration
define( 'DB_NAME', 'wp_inorout' );
define( 'DB_USER', 'inorout' );
define( 'DB_PASSWORD', '6jBGmYwPbQKJNfnx' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY', ':ycGxh|6KKLb2vTR= B<a(-YHWv775}-Nz)zR<rSxC/v/45lR)_KPI2GM!VZ.GHT');
define('SECURE_AUTH_KEY', '@~@Fz_I5J6apU*5NGzy]j`<a1*3N m+^Z-gfvI#].U5vC6[Bl^K-*m&6uOeZX>^-');
define('LOGGED_IN_KEY', 's!FRR9@CTu=wg:%hGd[fs>,Pq +P9,D@%)?`Y*c=.)77=p?0$  Hr:8QPYM%{a]/');
define('NONCE_KEY', 'T^9uqgB^:G.096sP`mlm>ePe3YBWU!F{mYLqk+%,GmC/*wWi=#kGpm=Fr?9v+K5/');
define('AUTH_SALT',        'g-^jR6=,P-$u)3WEO4c,,sV|j]q,P)o2Q,a@%VC{}7D3,ah|`p|*%{(6lj-Q}}>m');
define('SECURE_AUTH_SALT', 'Xx_!G||4gID+T34+<-BFQHCLO4/&(ZC2lH^?3Hp2QHws6Da8r*6_KB#FM$h;zG$R');
define('LOGGED_IN_SALT',   'c<x/[@Eh&t*DgI[$C@n5v]ge`k2z$$n-T~<dv_k3k3]gquMbl^yo.:GNE>%SuKj(');
define('NONCE_SALT',       'r-+i9nRi)Qs0ELA)XfpKx9hG$2b7O.;3HrAHv+N3$8!Bo<a7{FX|8GE/D$x6t^*:');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'PWP_NAME', 'inorout' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', '02cd8ad9e950f4d539d1a84accdcfc3b7eba7428' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '40103' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_CDN_DISABLE_ALLOWED', false );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'www.inorout.us', 1 => 'inorout.us', 2 => 'inorout.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-40103', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );

define( 'WPE_BETA_TESTER', false );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_AUTO_UPDATE_CORE', false );

$wpe_special_ips=array ( 0 => '45.56.116.175', );

$wpe_netdna_domains_secure=array ( );

define( 'WPE_CACHE_TYPE', 'generational' );

define( 'WPE_LBMASTER_IP', '45.56.116.175' );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_HYPER_DB', 'safe' );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
