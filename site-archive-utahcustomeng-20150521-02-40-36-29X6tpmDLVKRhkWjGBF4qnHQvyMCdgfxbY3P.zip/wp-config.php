<?php
# Database Configuration
define( 'DB_NAME', 'wp_utahcustomeng' );
define( 'DB_USER', 'utahcustomeng' );
define( 'DB_PASSWORD', 'oK32uEQaxPhfNFIWA6WA' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY',         '=3*h hO-#D=D$B|vivv#;Csxd?w+rsrwzQSJ6|}Q^4MiKcu|lr&L3G]u1yX1bg-U');
define('SECURE_AUTH_KEY',  'tWR`@I$Mi5QX^lZe[_H+/HOWhf99)L&QQ=pbLp9w4jHP+UF2zIo1]-(Mj+K|N/Gv');
define('LOGGED_IN_KEY',    'UQvD0)ZlO1un~[fW5t_Q,u?6(@PzfsfBFjo<[uh{3eS8u*[p&[S#2xf07t_1.aO!');
define('NONCE_KEY',        '`ftv|=R$Fgu-h>egh/+7OVOvvQnd 1nc^jq+]bh+i<[JeW=,8PRe0:fb>&}KO9vL');
define('AUTH_SALT',        'DL)`n,%3Et3b% 4#euYj*Ld%F=>ANh`m]~Z}$E7`lM${ CIaU&D+[jm}]?&E 5v<');
define('SECURE_AUTH_SALT', '%/jt<r!^B8crn_J$BToG8EV><}UWT%YL_C>7Bsh+m$EaasO&tcE-g9*;eV!{4!g`');
define('LOGGED_IN_SALT',   '8~Io`T<C<W-.{&3Do-`y~fM4`- j&|YZA;Ti~Ev3 *M9AF{Cwws8c$8%[7wTTJiX');
define('NONCE_SALT',       'Zp|,a0QfPR7zrtRaOJHVOKpe7[$<h$5-X.S#uq4~;GLCDKxY)T[O_ g7v3lL&v7O');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'utahcustomeng' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', 'fc28b8587144aa5a4f601ebdc5c66f2d4e381bb9' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '40750' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_LBMASTER_IP', '66.228.47.253' );

define( 'WPE_CDN_DISABLE_ALLOWED', true );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'utahcustomeng.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-40750', );

$wpe_special_ips=array ( 0 => '66.228.47.253', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_domains_secure=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );

define( 'WPE_SFTP_PORT', 2222 );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
