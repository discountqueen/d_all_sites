<?php
# Database Configuration
define( 'DB_NAME', 'wp_billwright' );
define( 'DB_USER', 'billwright' );
define( 'DB_PASSWORD', 'mjVn3BWzgbKrCvd7' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define( 'DB_CHARSET', 'utf8' );
define( 'DB_COLLATE', 'utf8_unicode_ci' );
$table_prefix = 'wp_';



# Security Salts, Keys, Etc
define( 'AUTH_KEY', '>*X6S@!9rI3(~jxVyt0np[>+Td=`WdkCNW<414}M tgc_wJPosM4fku1O/If|2~+' );
define( 'SECURE_AUTH_KEY', '!S;Y)z+T*#W>CkA8,;pc.0@V=2NDXB-8[ -LdW=nPRZpz@}2*xg,*jgK+tgc% ;O' );
define( 'LOGGED_IN_KEY', 'f1X^FrUa,9>NzA/3 ]X/:&rI2&BXP#*mo[|3X+7`1mMWi$m-=Fto/Z*Y|]-c+o|o' );
define( 'NONCE_KEY', 'd8kq;jnWJq?/E0V,{q-_MG:(d|VnNlg5aV&|}0|0*N|F<+c@E9_x2Ewm=gOXi}Q=' );
define( 'AUTH_SALT', 'q>v|_4^;_Mg[0-SBP`-H0_ULu$xqJzp`.pe00M~k/{TY-+/6!fJ;.p+s|u_r-hr:' );
define( 'SECURE_AUTH_SALT', 'KsX=:cr1@<sn^9(?|;C<=QMU! zm~W]Eu$7*ndv.-Qm~LvW%_/OssIBy+(bE0%TZ' );
define( 'LOGGED_IN_SALT', 'i*LF.,^z<v^drt1v@^WU]@t:Ph4_9,|^]EbL}![RL@|*8o-OM}u$:!u`z@0!=^p#' );
define( 'NONCE_SALT', 'XN96Z[K14)kxm/!f<~E<OOiY|l|4+$9=l0J&e|Mfy.M!(DAMn;VR.M/6X+.7yDBN' );



# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'billwright' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', 'f87d78b96ac49f6e6223d192b1e2a2cb1078ae41' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '10390' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_SFTP_PORT', 22 );

define( 'WPE_LBMASTER_IP', '104.130.144.27' );

define( 'WPE_CDN_DISABLE_ALLOWED', false );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'billwright.wpengine.com', 1 => 'www.billwrightforutah.com', 2 => 'billwrightforutah.com', );

$wpe_varnish_servers=array ( 0 => 'pod-10390', );

$wpe_special_ips=array ( 0 => '23.253.227.48', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_domains_secure=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );
define( 'WPLANG', '' );



# WP Engine Settings





define( 'WPE_CACHE_TYPE', 'generational' );



























/*SSLSTART*/
if ( isset( $_SERVER['HTTP_X_WPE_SSL'] ) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on';
/*SSLEND*/



# Custom Settings












$_wpe_preamble_path = null;



# That's It. Pencils down
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname(__FILE__) . '/' );
}
require_once( ABSPATH . 'wp-settings.php' );

$_wpe_preamble_path = null; if(false){}
