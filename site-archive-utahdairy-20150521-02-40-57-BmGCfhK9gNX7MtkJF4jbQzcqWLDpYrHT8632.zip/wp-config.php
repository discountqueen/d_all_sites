<?php
# Database Configuration
define( 'DB_NAME', 'wp_utahdairy' );
define( 'DB_USER', 'utahdairy' );
define( 'DB_PASSWORD', 'Xf9zgpYQNyqVB4wW' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY', '+D(6174@cv*_d:56K3&Ab *dC-AR,pjPJNUG#Zy(A-+JU1zI!eL-~g/94t|KeUrd');
define('SECURE_AUTH_KEY', 'v|BgTi6(6~{IHoD<:-m#qBBYT ?_s)K4jWfGI&ZGGe1pUq-a08B>C#H<NdfS~G|B');
define('LOGGED_IN_KEY', '_,!nq}k>>pCEj+RZt3.+yV/Z=xWvi+N{F )1``m#D5,sH$RnM6{A5cWt<V*#WCY+');
define('NONCE_KEY', 'Q,|z 4YlFSb*-4Shj^sy;xuc71S0T*J{.GHGv!s`NT)+Fmm8p3|!nT-%Sv11N6YB');
define('AUTH_SALT',        '?%6tl7XK-CQbimLP|L$ajh7764Y3.J4F|++ -!G4w|G;B9H&+jAe?lD_|v2SF(,6');
define('SECURE_AUTH_SALT', 'o--bN6%p3UZQ[-7(>U$/- )^ofJ} {&=A/Ezm|/%6@fpchX* f6.@o_8L;b_-UrP');
define('LOGGED_IN_SALT',   'w7SIb_iB<BF.T<j-^4lzY}}q#Ya@r4.>7P!rC7<67wvRr5#@nJ[XTPdweMSQATu$');
define('NONCE_SALT',       'Qp6lo*PTM,^so+wD~.Mb:y9(F)X$r{vpb}t[j@2^Jc?S@[E|jnbOy-UCJaN}%%J8');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'PWP_NAME', 'utahdairy' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', 'e647495dd6cc562c94af4e21c15431e1370d9262' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '40103' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_CDN_DISABLE_ALLOWED', false );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'www.utahdairy.com', 1 => 'utahdairy.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-40103', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );

define( 'WPE_BETA_TESTER', false );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_AUTO_UPDATE_CORE', false );

$wpe_special_ips=array ( 0 => '45.56.116.175', );

$wpe_netdna_domains_secure=array ( );

define( 'WPE_CACHE_TYPE', 'generational' );

define( 'WPE_LBMASTER_IP', '45.56.116.175' );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_HYPER_DB', 'safe' );
define('WPLANG','');

/* Multisite */
define('WP_ALLOW_MULTISITE', true);
define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', false);
define('DOMAIN_CURRENT_SITE', 'www.utahdairy.com');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);


# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
