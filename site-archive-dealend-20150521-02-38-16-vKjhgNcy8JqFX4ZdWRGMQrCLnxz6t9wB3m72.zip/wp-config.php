<?php
# Database Configuration
define( 'DB_NAME', 'wp_dealend' );
define( 'DB_USER', 'dealend' );
define( 'DB_PASSWORD', '82KwFBZcnzfkqtWb' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define( 'DB_CHARSET', 'utf8' );
define( 'DB_COLLATE', 'utf8_unicode_ci' );
$table_prefix = 'wp_';



# Security Salts, Keys, Etc
define( 'AUTH_KEY', ';u<[qFSOs^9SlVy9`fH+t=D8KC*X9F&*]o_G3-7XF~C-+U6Lt+FB1P- *!]siZ82' );
define( 'SECURE_AUTH_KEY', 'rcbOhb IKx}W}.%FNrv:$nb`Cs9iX7)!#T9[UG^yW*))e&xXkhv,y8WFz~kEiZM5' );
define( 'LOGGED_IN_KEY', '~<q$S`hvLl(|/QO`}5iG#*mK+KhwM#xMmJ-(V+6Ch-R_n{>LoZ+O#_-fg!/B+B2d' );
define( 'NONCE_KEY', '{Zhz!t*+I|}^(`!*r@_yMtS.%lJxW}mFx6HP20/#KYwSq^w)4.ex}|O1s}s+D,uN' );
define( 'AUTH_SALT', 'c{Kkp?tmQ%zxBtV[M{a[wr#@upmnvU|1fSlNE7GyEDF!^p]il!P]-I#Leg`oa.D@' );
define( 'SECURE_AUTH_SALT', 'Xe/Z4yIj h??k-?qsDbc{J<<W*1!vAwtY*p}&@ze4S4my^|NA,%0{:(U!^+{#[]U' );
define( 'LOGGED_IN_SALT', 'nQBKAup,WmMl{qM%/3AJZg#u[A<Rp#&{!VF*w=ZoQL{- |E]%_5P_L2o4-GjY{3=' );
define( 'NONCE_SALT', '7)pJ9b*T2%N#q#OMhVKINi|!~p5,Vakv=v|r8lUk-[-TUO&&#N-c/shz)eM&9sc]' );



# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'dealend' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', 'c2b42a2c3ab91a9117e8aa485267414783031971' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '10390' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_SFTP_PORT', 22 );

define( 'WPE_LBMASTER_IP', '104.130.144.27' );

define( 'WPE_CDN_DISABLE_ALLOWED', false );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'dealend.wpengine.com', 1 => 'dealend.co', );

$wpe_varnish_servers=array ( 0 => 'pod-10390', );

$wpe_special_ips=array ( 0 => '23.253.227.48', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_domains_secure=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );
define( 'WPLANG', '' );



# WP Engine Settings





define( 'WPE_CACHE_TYPE', 'generational' );



























/*SSLSTART*/
if ( isset( $_SERVER['HTTP_X_WPE_SSL'] ) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on';
/*SSLEND*/



# Custom Settings












$_wpe_preamble_path = null;



# That's It. Pencils down
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname(__FILE__) . '/' );
}
require_once( ABSPATH . 'wp-settings.php' );

$_wpe_preamble_path = null; if(false){}
