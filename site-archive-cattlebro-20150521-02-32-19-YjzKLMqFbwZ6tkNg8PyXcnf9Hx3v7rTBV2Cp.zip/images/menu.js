var left;
var right;
var top;

left_space = (window.screen.width/2)-105;
right_space = (window.screen.width/2)-157;
new ypSlideOutMenu("menu1", "right", left_space, 270, 172, 250);


document.write(navMenu1);


function window_onload()
{

}

var slider;
 var ypSlideOutMenu;
 var navMenu1;
function changeBG(whichOne)
{
whichOne.bgColor = "#591C1B"

}
function changeBGX(whichOne)
{
whichOne.bgColor = "#84252B"

}