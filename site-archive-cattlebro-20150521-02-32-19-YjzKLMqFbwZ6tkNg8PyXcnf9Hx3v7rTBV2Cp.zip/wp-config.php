<?php
# Database Configuration
define( 'DB_NAME', 'wp_cattlebro' );
define( 'DB_USER', 'cattlebro' );
define( 'DB_PASSWORD', 'ChNDF8fV64qrWvHp' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');

# Security Salts, Keys, Etc
define('AUTH_KEY',         '&@/O{YOb^oh)yb84r~M`7YK{D)^Dj#|_5uF<^x0Ow]c3f:,C+qe?t}D37?6Ht:|0');
define('SECURE_AUTH_KEY',  'N=^Q/o:_L:oIEb~p|sT1Q>eM?+>c;sq<6&B7KTdGRMsE+(kZ*8{hm]?]]a^vbm+M');
define('LOGGED_IN_KEY',    't#fweqBE uDj@]hz3wM6Mx/z&l25t)W_R8eTkSP>TObl6Z%^C_U@y{3)UI=?[@es');
define('NONCE_KEY',        '(RN$Rx6m 0v3U$+BJy<J]n~7H@9O-ne7sP-N]+@]]1-_-Zi$Ef0r(1)(:uMy [_k');
define('AUTH_SALT',        'j D|j UN^pOdfOcc0J8cO~[ZcvimPy<bv&lNOG##uM>`X]eLu?+TE,` v|#6*(?m');
define('SECURE_AUTH_SALT', ']m?nF!44;5jnSPyS@|]IfpW_Guw&`jiz@+Y4kmn=u=T*bdptI,^NWRy$EMlytQ~N');
define('LOGGED_IN_SALT',   'UyR+{:4HHPL0,d|4%iD`|+15c#S);,39+IkSi{b=W]JSY[VAShfYI?XI!d9sWt`l');
define('NONCE_SALT',       'dG1l`Xs:iD*|/@oxTgg3)-bTiA$7%T#-U2` TUU:X2J ={/,@GE[i(`;yeuqE%&|');

$table_prefix = 'wp_';


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'PWP_NAME', 'cattlebro' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', 'ea2a11f8f58c92e0118feb38c728908ccc79229d' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '40103' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_CDN_DISABLE_ALLOWED', false );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'cattlebro.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-40103', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );

define( 'WPE_BETA_TESTER', false );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_AUTO_UPDATE_CORE', false );

$wpe_special_ips=array ( 0 => '45.56.116.175', );

$wpe_netdna_domains_secure=array ( );

define( 'WPE_CACHE_TYPE', 'generational' );

define( 'WPE_LBMASTER_IP', '45.56.116.175' );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_HYPER_DB', 'safe' );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
