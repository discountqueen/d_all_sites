<?php
# Database Configuration
define( 'DB_NAME', 'wp_goldstar' );
define( 'DB_USER', 'goldstar' );
define( 'DB_PASSWORD', 'PduidImzX2CqhLs2NKRU' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY',         '[W`{b@h.3f9m:3OHoN5?vi1,.]7G<#Q:yqUiC%NOm@#;o!BT7U^5/@+;2|KTQr`W');
define('SECURE_AUTH_KEY',  'jhArXQB/~hr?]GHXH2|knT@j=3T`eSp}93cF9<Kzx*3R|V5;NgZ;tL533+HD 0u5');
define('LOGGED_IN_KEY',    'g*dIk-^-S~;v<L]zafCY}5&[XyT(v+9mwy8J@jgc}Qr~VK>-+JS-7;s)`qgq%a~<');
define('NONCE_KEY',        'gvD^,bkB|ysCo|^A|6OckP)CL%l[a?^^&$Jg+0S_ND08h,,?4=lhdXvZFpC&T.xX');
define('AUTH_SALT',        'D5f~u|]gbqM8$pTMV-x`u+s}Ma) GmzF9o+Xo`?l7*z|hqRElFa.^#+J;,{*-},D');
define('SECURE_AUTH_SALT', 'SVtwI5IHYD4_TdCK?YLp9i-}X}hz(?wR_>$o8Oqti/K-2PB~hi,xj!t/ZB9koS=:');
define('LOGGED_IN_SALT',   '|0+pYQ!JWEsqc0m+Va~8p6)V7FI`QK|3:1GWu`]z>c7/U! HwIvrdljsU8}LFJ[#');
define('NONCE_SALT',       '>D_q)hF<Wf{Ksd`#SZg;f:Un<hv-m!<c;hhh=BQlE+M#t@>Jbf(U0zbkON/O}+(4');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'goldstar' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', '1db92b2e1e71a0610f94153bada3bb101e977d3a' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '40103' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_CACHE_TYPE', 'generational' );

define( 'WPE_LBMASTER_IP', '45.56.116.175' );

define( 'WPE_CDN_DISABLE_ALLOWED', true );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'goldstar.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-40103', );

$wpe_special_ips=array ( 0 => '45.56.116.175', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_domains_secure=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_HYPER_DB', 'safe' );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
